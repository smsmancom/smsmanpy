from .requests import (Smsman)
from .exeptions import (Error, WrongTokenError, SMSnotReceivedError, LowBalance, NoNumbers)

__autor__ = 'https://github.com/Byrboniti'
__version__ = '0.0.1'
__email__ = 'rewer-96@mail.ru'